function varargout = updateApp(varargin)

% 声明持久变量存放参数

rto1 = get_param('speed/Out1_speed','RuntimeObject');

str1 = num2str(rto1.InputPort(1).Data);

rto2 = get_param('speed/Out2','RuntimeObject');

str2 = num2str(rto2.InputPort(1).Data);

% 获取界面中的绘图句柄

all_tag_objects = findall(0, '-property', 'tag');

all_tags = get(all_tag_objects, 'tag');

[tf, idx] = ismember('Out1', all_tags);

if tf  

  st1 = all_tag_objects(idx);

end

[tf, idx] = ismember('Out2', all_tags);

if tf  

  st2 = all_tag_objects(idx);

end



% 更新GUI显示

set(st2,'Value',str2double(str2));

set(st1,'Value',str2double(str1));
