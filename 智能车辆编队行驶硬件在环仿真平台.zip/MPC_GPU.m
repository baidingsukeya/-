function [sys, x0, str, ts] = MPC_GPU(t, x, u, flag)
    switch flag
        case 0
            [sys, x0, str, ts] = mdlInitializeSizes();
        case 1
            sys = mdlDerivatives(t, x, u);
        case 3
            sys = mdlOutputs(t, x, u);
        case {2, 4, 9}
            sys = [];
        otherwise
            error(['Unhandled flag = ', num2str(flag)]);
    end
end

function params = getParams()
    %% ��������
    params.m = 1000; % ��������
    params.g = 9.81; % �������ٶ�
    params.f = 0.015; % ��������ϵ��
    params.xita = 0.05; % �¶Ƚ�
    params.rou = 1.225; % �����ܶ�
    params.Cd = 0.32; % Cdֵ
    params.A = 2.2; % ӭ�����
    params.delta = 1; % ����ת������ϵ��
    params.yita = 0.9; % ����Ч��
    params.afa = 0.5; % ���Ч��

    params.vmin = 0; % ��С�ٶ�
    params.vmax = 30; % ����ٶ�
    params.amin = -300; % ��С���ٶ�
    params.amax = 300; % �����ٶ�
    params.Tmin = 0; % ��Сת��
    params.Tmax = 100; % ���ת��

    % ���Ч�ʲ������
    params.speed_values = [0 500 1000 1500 2000 2500 3000 3500 4000 4500 5000 5500 6000 6500 7000 7500 8000 8500 9000 9500 10000 10500 11000 11500 12000]; % RPM
    params.torque_values = [0 25 50 75 100 125 150 175 200 225 250 275 300]; % Nm
    params.efficiency_values = [
        0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7 0.7;
        0.7 0.73 0.75 0.77 0.78 0.785 0.79 0.795 0.80 0.805 0.807 0.81 0.805 0.80 0.80 0.795 0.79 0.782 0.78 0.76 0.75 0.745 0.73 0.72 0.72;
        0.7 0.745 0.78 0.805 0.82 0.83 0.84 0.845 0.855 0.86 0.865 0.865 0.86 0.857 0.85 0.845 0.835 0.82 0.81 0.80 0.785 0.77 0.75 0.74 0.73;
        0.7 0.755 0.80 0.825 0.845 0.86 0.87 0.88 0.885 0.89 0.90 0.89 0.883 0.873 0.865 0.855 0.845 0.83 0.815 0.803 0.79 0.778 0.76 0.75 0.745;
        0.7 0.76 0.81 0.835 0.855 0.868 0.885 0.895 0.905 0.91 0.915 0.895 0.885 0.875 0.865 0.85 0.84 0.823 0.81 0.80 0.79 0.783 0.775 0.77 0.77;
        0.7 0.765 0.81 0.84 0.86 0.875 0.89 0.90 0.915 0.915 0.915 0.895 0.88 0.868 0.855 0.847 0.832 0.815 0.80 0.795 0.79 0.785 0.782 0.782 0.78;
        0.7 0.775 0.82 0.86 0.875 0.885 0.89 0.90 0.905 0.90 0.895 0.883 0.868 0.858 0.85 0.843 0.83 0.815 0.807 0.798 0.79 0 0 0 0;
        0.7 0.77 0.82 0.858 0.87 0.878 0.88 0.88 0.88 0.88 0.875 0.86 0.84 0.83 0.823 0.819 0.815 0.81 0 0 0 0 0 0 0;
        0.7 0.77 0.818 0.845 0.86 0.867 0.861 0.858 0.85 0.85 0.848 0.838 0.818 0.812 0.81 0.808 0 0 0 0 0 0 0 0 0;
        0.7 0.76 0.81 0.84 0.85 0.855 0.845 0.838 0.83 0.83 0.83 0.82 0.81 0.805 0 0 0 0 0 0 0 0 0 0 0 0;
        0.7 0.755 0.80 0.83 0.838 0.84 0.83 0.825 0.816 0.818 0.822 0.815 0.81 0 0 0 0 0 0 0 0 0 0 0 0;
        0.7 0.75 0.791 0.818 0.823 0.823 0.817 0.815 0.813 0.813 0.811 0.81 0 0 0 0 0 0 0 0 0 0 0 0 0;
        0.7 0.75 0.79 0.805 0.81 0.81 0.805 0.80 0.80 0.803 0.802 0 0 0 0 0 0 0 0 0 0 0 0 0 0;
    ];
end

function [sys, x0, str, ts] = mdlInitializeSizes()
    sizes = simsizes;
    sizes.NumContStates  = 0;
    sizes.NumDiscStates  = 0;
    sizes.NumOutputs     = 3;  % ���
    sizes.NumInputs      = 4;  % ����
    sizes.DirFeedthrough = 1;
    sizes.NumSampleTimes = 1;

    sys = simsizes(sizes);
    x0  = [];
    str = [];
    ts  = [0 0];
    efficiency = 0.9;
end

function sys = mdlDerivatives(~, ~, ~)
    sys = [];
end

function sys = mdlOutputs(t, x, u)
    % ��ȡ����
    x0 = u(1:2); % ����1,2
    N = u(3); % Ԥ�ⲽ��
    dt = u(4); % ����

    % ��û�������
    params = getParams();

    % �����������
    lb = params.amin * ones(N, 1);
    ub = params.amax * ones(N, 1);

    % ��ʼ��ֵ
    u0 = zeros(N, 1);

    % ����Ż�����
    optimal_u = solveOptimization(u0, x0, params, N, dt, lb, ub);

    % ������ſ�������
    optimal_x = simulateSystem(optimal_u, x0, params, N, dt);
    sys = [optimal_u(1); optimal_x(:,1)];
end

function optimal_u = solveOptimization(u0, x0, params, N, dt, lb, ub)
    % ʹ�� GPU �����Ż�
    options = optimoptions('fmincon', 'UseParallel', true, 'Display', 'iter','sqp','MaxIterations',10);

    % ���� fmincon �����Ż�
    optimal_u = fmincon(@(u) objectiveFunctionOnGPU(u, x0, params, N, dt), u0, [], [], [], [], lb, ub, [], options);
end

function J = objectiveFunctionOnGPU(u, x0, params, N, dt)
    % ʹ�� GPU ���м���
    u = gpuArray(u);
    x = gpuArray(x0);
    J = 0;
    for k = 1:N
        dx = systemDynamics(x, u(k), params);
        x = x + dx * dt;
        J = J + costFunction(x, u(k));
    end
    J = gather(J); % ������� GPU �ƻ� CPU
end

function dx = systemDynamics(x, u, params)
    % ����ϵͳ����ѧ������ĳ������ϵͳģ��
    dx = zeros(size(x));
    dx(1) = x(2); % dx1/dt = �ٶ�
    dx(2) = -params.a * x(1) - params.b * x(2) + params.c * u; % dx2/dt = ���ٶ�
end

function J = costFunction(x, u)
    % ����ɱ�����
    J = x(1)^2 + x(2)^2 + u^2;
end

function efficiency = getMotorEfficiency(speed, torque, params)
    % ʹ�� GPU ���в�ֵ���ҵ��Ч��
    efficiency = interp2(params.speed_values, params.torque_values, params.efficiency_values, speed, torque, 'linear', 0);
end

function optimal_x = simulateSystem(optimal_u, x0, params, N, dt)
    optimal_x = zeros(2, N);
    optimal_x(:, 1) = x0;
    for k = 1:N
        dx = systemDynamics(optimal_x(:, k), optimal_u(k), params);
        optimal_x(:, k+1) = optimal_x(:, k) + dx * dt;
    end
end

