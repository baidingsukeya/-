load 'motor_75kw.mat'
eff_trans = 0.90;
Kp=0.3;
Ki=0.0;
T_brk_max = 800;
r_regen = 0.3;
Bat_Cap_Ah=200;
SOC_initial=0.8; 
Mot_eff = Mot_eff';