function varargout = updateApp_prescan(varargin)

% 声明持久变量存放参数
    persistent callCount
    
    % 初始化调用次数
    if isempty(callCount)
        callCount = 0;
    end
    
% 每次回调函数被调用时，调用次数加1
    callCount = callCount + 1;
    
    if mod(callCount, 10000) == 0
        rto1 = get_param('prescan_carsim_2016_cs/Outspeed1','RuntimeObject');

        str1 = num2str(rto1.InputPort(1).Data);
        
        rto2 = get_param('prescan_carsim_2016_cs/Outspeed2','RuntimeObject');
        
        str2 = num2str(rto2.InputPort(1).Data);
        
        rto3 = get_param('prescan_carsim_2016_cs/Outspeed3','RuntimeObject');
        
        str3 = num2str(rto3.InputPort(1).Data);
        
        rto4 = get_param('prescan_carsim_2016_cs/Outspeed4','RuntimeObject');
        
        str4 = num2str(rto4.InputPort(1).Data);
        
        rto5 = get_param('prescan_carsim_2016_cs/Outspeed5','RuntimeObject');
        
        str5 = num2str(rto5.InputPort(1).Data);
        
        rto6 = get_param('prescan_carsim_2016_cs/Outspeed6','RuntimeObject');
        
        str6 = num2str(rto6.InputPort(1).Data);
        % 获取界面中的绘图句柄
        
        all_tag_objects = findall(0, '-property', 'tag');
        
        all_tags = get(all_tag_objects, 'tag');
        
        [tf, idx] = ismember('Out1', all_tags);
        
        if tf  
        
          st1 = all_tag_objects(idx);
        
        end
        
        [tf, idx] = ismember('Out2', all_tags);
        
        if tf  
        
          st2 = all_tag_objects(idx);
        
        end
        
        [tf, idx] = ismember('Out3', all_tags);
        
        if tf  
        
          st3 = all_tag_objects(idx);
        
        end
        
        [tf, idx] = ismember('Out4', all_tags);
        
        if tf  
        
          st4 = all_tag_objects(idx);
        
        end
        
        [tf, idx] = ismember('Out5', all_tags);
        
        if tf  
        
          st5 = all_tag_objects(idx);
        
        end
        
        [tf, idx] = ismember('Out6', all_tags);
        
        if tf  
        
          st6 = all_tag_objects(idx);
        
        end



        % 更新GUI显示
        
        set(st2,'Value',str2double(str2));
        
        set(st1,'Value',str2double(str1));
        
        set(st3,'Value',str2double(str3));
        
        set(st4,'Value',str2double(str4));
        
        set(st5,'Value',str2double(str5));
        
        set(st6,'Value',str2double(str6));
                    % 执行你的逻辑
                    % ...
    end
